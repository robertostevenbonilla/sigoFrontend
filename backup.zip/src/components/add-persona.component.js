import React, { Component } from "react";
import PersonaDataService from "../services/persona.service";

export default class AddPersona extends Component {
  constructor(props) {
    super(props);
    this.onChangeNombres = this.onChangeNombres.bind(this);
    this.onChangeApellidos = this.onChangeApellidos.bind(this);
    this.onChangeIdentificacion = this.onChangeIdentificacion.bind(this);
    this.onChangeEmail = this.onChangeEmail.bind(this);
    this.onChangeTelefono = this.onChangeTelefono.bind(this);
    this.onChangeEmpresaId = this.onChangeEmpresaId.bind(this);
    this.savePersona = this.savePersona.bind(this);
    this.newPersona = this.newPersona.bind(this);

    this.state = {
      id: null,
      nombres: "",
      apellidos: "",
      fullName: "",
      identificacion: "",
      email: "",
      telefono: "",
      estado: "",
      empresaId: "",
      empresas: [],
      published: false,
      submitted: false,
    };
  }

  onChangeNombres(e) {
    this.setState({
      nombres: e.target.value,
    });
  }

  onChangeApellidos(e) {
    this.setState({
      apellidos: e.target.value,
    });
  }

  onChangeIdentificacion(e) {
    this.setState({
      identificacion: e.target.value,
    });
  }

  onChangeEmail(e) {
    this.setState({
      email: e.target.value,
    });
  }

  onChangeTelefono(e) {
    this.setState({
      telefono: e.target.value,
    });
  }

  onChangeEmpresaId(e) {
    this.setState({
      empresaId: e.target.value,
    });
  }

  savePersona() {
    var data = {
      nombres: this.state.nombres,
      apellidos: this.state.apellidos,
      identificacion: this.state.identificacion,
      email: this.state.email,
      telefono: this.state.telefono,
      estado: this.state.estado,
      empresaId: this.state.empresaId,
    };

    PersonaDataService.create(data)
      .then((response) => {
        const persona = response.data;
        this.setState({
          ...persona,
          submitted: true,
        });
        console.log(persona);
      })
      .catch((e) => {
        console.log(e);
      });
  }

  newPersona() {
    this.setState({
      ...this.state,
    });
  }

  render() {
    return (
      <div className="submit-form">
        {this.state.submitted ? (
          <div>
            <h4>Se ha enviado correctamente!</h4>
            <p>{this.state.fullName}</p>
            <button className="btn btn-success" onClick={this.newPersona}>
              Add
            </button>
          </div>
        ) : (
          <div>
            <div className="form-group">
              <label htmlFor="nombres">Nombres</label>
              <input
                type="text"
                className="form-control"
                id="nombres"
                required
                value={this.state.nombres}
                onChange={this.onChangeNombres}
                name="nombres"
              />
            </div>
            <div className="form-group">
              <label htmlFor="apellidos">Apellidos</label>
              <input
                type="text"
                className="form-control"
                id="apellidos"
                required
                value={this.state.apellidos}
                onChange={this.onChangeApellidos}
                name="apellidos"
              />
            </div>
            <div className="form-group">
              <label htmlFor="identificacion">Identificación</label>
              <input
                type="text"
                className="form-control"
                id="identificacion"
                required
                value={this.state.identificacion}
                onChange={this.onChangeIdentificacion}
                name="identificacion"
              />
            </div>
            <div className="form-group">
              <label htmlFor="email">Email</label>
              <input
                type="text"
                className="form-control"
                id="email"
                required
                value={this.state.email}
                onChange={this.onChangeEmail}
                name="email"
              />
            </div>
            <div className="form-group">
              <label htmlFor="telefono">Telefono</label>
              <input
                type="text"
                className="form-control"
                id="telefono"
                required
                value={this.state.telefono}
                onChange={this.onChangeTelefono}
                name="telefono"
              />
            </div>
            <div className="form-group">
              <label htmlFor="empresaId">Empresa</label>
              <input
                type="text"
                className="form-control"
                id="empresaId"
                required
                value={this.state.empresaId}
                onChange={this.onChangeEmpresaId}
                name="empresaId"
              />
            </div>

            <button onClick={this.savePersona} className="btn btn-success">
              Enviar
            </button>
          </div>
        )}
      </div>
    );
  }
}
