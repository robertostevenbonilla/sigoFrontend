import React, { Component } from "react";
import PersonaDataService from "../services/persona.service";
import { Link } from "react-router-dom";

export default class PersonaList extends Component {
  constructor(props) {
    super(props);
    
    this.onChangeSearchNombres = this.onChangeSearchNombres.bind(this);
    this.retrievePersonas = this.retrievePersonas.bind(this);
    this.refreshList = this.refreshList.bind(this);
    this.setActivePersona = this.setActivePersona.bind(this);
    this.searchNombres = this.searchNombres.bind(this);

    this.state = {
      personas: [],
      currentPersona: null,
      currentIndex: -1,
      searchNombres: "",
    };
  }

  componentDidMount() {
    this.retrievePersonas();
  }

  onChangeSearchNombres (e) {
    const searchNombres = e.target.value;

    this.setState({
      searchNombres: searchNombres,
    });
  }

  retrievePersonas() {
    PersonaDataService.getAll()
      .then((response) => {
        this.setState({
          personas: response.data,
        });

        console.log(response.data);
      })
      .catch((e) => {
        console.log(e);
      });
  }

  refreshList() {
    this.retrievePersonas();
    this.setState({
      currentPersona: null,
      currentIndex: -1,
    });
  }

  setActivePersona(persona, index) {
    this.setState({
      currentPersona: persona,
      currentIndex: index,
    });
  }

  searchNombres() {
    PersonaDataService.findByNombres(this.state.searchNombres)
      .then((response) => {
        this.setState({
          personas: response.data,
          currentPersona: null,
          currentIndex: -1,
        });
        console.log(response.data);
      })
      .catch((e) => {
        console.log(e);
      });
  }

  render() {
    const { searchNombres, personas, currentPersona, currentIndex } =
      this.state;

    return (
      <div className="list row">
        <div className="col-md-8">
          <div className="input-group mb-3">
            <input
              type="text"
              className="form-control"
              placeholder="Buscar por nombres"
              value={searchNombres}
              onChange={this.onChangeSearchNombres}
            />
            <div className="input-group-append">
              <button
                className="btn btn-outline-secondary"
                type="button"
                onClick={this.searchNombres}
              >
                Search
              </button>
            </div>
          </div>
        </div>
        <div className="col-md-6">
          <h4>Personas</h4>

          <ul className="list-group">
            {personas &&
              personas.map((persona, index) => (
                <li
                  className={
                    "list-group-item " +
                    (index === currentIndex ? "active" : "")
                  }
                  onClick={() => this.setActivePersona(persona, index)}
                  key={index}
                >
                  {persona.fullName}
                </li>
              ))}
          </ul>
        </div>
        <div className="col-md-6">
          { currentPersona ? (
            <div>
              <h4>Persona</h4>
              <div>
                <label>
                  <strong>Nombres:</strong>
                </label>{" "}
                {currentPersona.nombres}
              </div>
              <div>
                <label>
                  <strong>Apellidos:</strong>
                </label>{" "}
                {currentPersona.apellidos}
              </div>

              <Link
                to={"/persona/" + currentPersona.id}
                className="badge badge-warning"
              >
                Edit
              </Link>
            </div>
          ) : (
            <div>
              <br />
              <p>Please click on a Persona...</p>
            </div>
          )}
        </div>
      </div>
    );
  }
}
