import React, { Component } from "react";
import PersonaDataService from "../services/persona.service";
import { withRouter } from "../common/with-router";

class Persona extends Component {
  constructor(props) {
    super(props);
    this.onChangeNombres = this.onChangeNombres.bind(this);
    this.onChangeApellidos = this.onChangeApellidos.bind(this);
    this.onChangeIdentificacion = this.onChangeIdentificacion.bind(this);
    this.onChangeEmail = this.onChangeEmail.bind(this);
    this.onChangeTelefono = this.onChangeTelefono.bind(this);
    this.onChangeEmpresaId = this.onChangeEmpresaId.bind(this);
    this.getPersona = this.getPersona.bind(this);
    this.updatePublished = this.updatePublished.bind(this);
    this.updatePersona = this.updatePersona.bind(this);
    this.deletePersona = this.deletePersona.bind(this);

    this.state = {
      currentPersona: {
        id: null,
        nombres: "",
        apellidos: "",
        fullName: "",
        identificacion: "",
        email: "",
        telefono: "",
        estado: "",
        empresaId: "",
        published: false,
      },
      message: "",
    };
  }

  componentDidMount() {
    this.getPersona(this.props.router.params.id);
  }

  onChangeNombres(e) {
    this.setState({
      nombres: e.target.value,
    });
  }

  onChangeApellidos(e) {
    this.setState({
      apellidos: e.target.value,
    });
  }

  onChangeIdentificacion(e) {
    this.setState({
      identificacion: e.target.value,
    });
  }

  onChangeEmail(e) {
    this.setState({
      email: e.target.value,
    });
  }

  onChangeTelefono(e) {
    this.setState({
      telefono: e.target.value,
    });
  }

  onChangeEmpresaId(e) {
    this.setState({
      empresaId: e.target.value,
    });
  }

  getPersona(id) {
    PersonaDataService.get(id)
      .then((response) => {
        this.setState({
          currentPersona: response.data,
        });
        console.log(response.data);
      })
      .catch((e) => {
        console.log(e);
      });
  }

  updatePersona() {
    PersonaDataService.update(
      this.state.currentPersona.id,
      this.state.currentPersona
    )
      .then(response => {
        console.log(response.data);
        this.setState({
          message: "The personal was updated successfully!"
        });
      })
      .catch(e => {
        console.log(e);
      });
  }

  deletePersona() {    
    PersonaDataService.delete(this.state.currentPersona.id)
      .then(response => {
        console.log(response.data);
        this.props.router.navigate('/persona');
      })
      .catch(e => {
        console.log(e);
      });
  }

  render() {
    const { currentPersona } = this.state;

    return (
      <div>
        {currentPersona ? (
          <div className="edit-form">
            <h4>Persona</h4>
            <form>
              <div className="form-group">
                <label htmlFor="nombres">Nombres</label>
                <input
                  type="text"
                  className="form-control"
                  id="nombres"
                  value={currentPersona.nombres}
                  onChange={this.onChangeNombres}
                />
              </div>
              <div className="form-group">
                <label htmlFor="apellidos">Apellidos</label>
                <input
                  type="text"
                  className="form-control"
                  id="apellidos"
                  value={currentPersona.apellidos}
                  onChange={this.onChangeApellidos}
                />
              </div>
              <div className="form-group">
                <label htmlFor="identificacion">Identificacion</label>
                <input
                  type="text"
                  className="form-control"
                  id="identificacion"
                  value={currentPersona.identificacion}
                  onChange={this.onChangeIdentificacion}
                />
              </div>
              <div className="form-group">
                <label htmlFor="email">Email</label>
                <input
                  type="text"
                  className="form-control"
                  id="email"
                  value={currentPersona.email}
                  onChange={this.onChangeEmail}
                />
              </div>
              <div className="form-group">
                <label htmlFor="telefono">Telefono</label>
                <input
                  type="text"
                  className="form-control"
                  id="telefono"
                  value={currentPersona.telefono}
                  onChange={this.onChangeTelefono}
                />
              </div>
              <div className="form-group">
                <label htmlFor="empresaId">EmpresaId</label>
                <input
                  type="text"
                  className="form-control"
                  id="empresaId"
                  value={currentPersona.empresaId}
                  onChange={this.onChangeEmpresaId}
                />
              </div>
            </form>

            <button
              className="badge badge-danger mr-2"
              onClick={this.deletePersona}
            >
              Delete
            </button>

            <button
              type="submit"
              className="badge badge-success"
              onClick={this.updatePersona}
            >
              Update
            </button>
            <p>{this.state.message}</p>
          </div>
        ) : (
          <div>
            <br />
            <p>Please click on a Persona...</p>
          </div>
        )}
      </div>
    );
  }
}

export default withRouter(Persona);
