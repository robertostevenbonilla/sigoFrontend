import http from "../http-common";

class PersonaDataService {
  getAll() {
    return http.get("/persona/");
  }

  get(id) {
    return http.get(`/persona/${id}`);
  }

  create(data) {
    return http.post("/persona/create", data);
  }

  update(id, data) {
    return http.put(`/persona/${id}`, data);
  }

  delete(id) {
    return http.delete(`/persona/${id}`);
  }

  findByEmpresa(id) {
    return http.get(`/persona/list?empresaId=${id}`);
  }

  findByNombres(nombres) {
    return http.get(`/persona/list?nombres=${nombres}`);
  }
}

export default new PersonaDataService();