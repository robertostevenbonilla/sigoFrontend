import React, { Component } from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import { Routes, Route, Link } from "react-router-dom";
import "./App.css";

import AddPersona from "./components/add-persona.component";
import Persona from "./components/persona.component";
import PersonaList from "./components/persona-list.component";

function App() {
  return (
    <div>
      <nav className="navbar navbar-expand navbar-dark bg-dark">
        <a href="/persona" className="navbar-brand">
          Sigo
        </a>
        <div className="navbar-nav mr-auto">
          <li className="nav-item">
            <Link to={"/persona"} className="nav-link">
              Personas
            </Link>
          </li>
          <li className="nav-item">
            <Link to={"/persona/add"} className="nav-link">
              Add
            </Link>
          </li>
        </div>
      </nav>

      <div className="container mt-3">
        <Routes>
          <Route path="/" element={<PersonaList />} />
          <Route path="/persona" element={<PersonaList />} />
          <Route path="/persona/add" element={<AddPersona />} />
          <Route path="/persona/:id" element={<Persona />} />
        </Routes>
      </div>
    </div>
  );
}

export default App;
